# Herramientas del sitio Stands

Sirven para que cada cambio o mejora se revise antes de subirse, y para saber **exactamente qué archivos subir**.
No se suben a GitHub: viven aparte del sitio.

## Requisitos
- Node.js y, dentro de esta carpeta: `npm install`
- Python con Playwright: `pip install playwright` y `python3 -m playwright install chromium`

## Flujo para cada cambio
1. Editar el archivo del módulo (por ejemplo `sitio/assets/clientes.js`).
2. `node sellar.js ../sitio` → actualiza las huellas y **lista los archivos nuevos o modificados que hay que subir**.
3. `node verificar.js ../sitio` → revisa sintaxis, nombres repetidos o no definidos, huellas, llave pública, navegación.
4. `node pruebas_calculo.js ../sitio` → prueba una por una las fórmulas de dinero y de fechas de `assets/calculo.js`.
5. `python3 pruebas_navegador.py ../sitio` → abre las páginas reales con una base simulada y recorre los flujos.
6. Subir a GitHub solo los archivos que indicó el paso 2.
7. `node sellar.js ../sitio --registrar` → guarda esta entrega como base para la siguiente comparación.

Si el paso 3 o 4 falla, no se sube nada hasta corregirlo.

## Cómo se organiza el sitio
- `index.html` (acceso), `clientes.html`, `costos.html`, `ajustes.html`: una página por módulo.
- `assets/` piezas compartidas, cargadas en este orden: `config.js` (conexión), `nucleo.js` (utilidades, paletas, formato),
  `ui.js` (íconos, hoja inferior, botón +, campo de motivo), `sesion.js` (sesión, encabezado, navegación), `calculo.js` (fórmulas de mano de obra y fechas, solo en las páginas que las usan), y el archivo del módulo.
- `assets/version.js` es el **único** lugar donde se escribe la versión. Solo lo carga Ajustes.
- `assets/estilos.css` tiene todos los estilos.

## Reglas para no romper nada
- Un nombre (función o constante) se define en un solo archivo. El verificador avisa si hay repetidos.
- La versión nunca se escribe a mano fuera de `version.js`.
- Si algo lo usarán dos módulos, va en `nucleo.js`, `ui.js` o `sesion.js`, no se copia.
- Después de editar un archivo, siempre correr `sellar.js`; si no, el verificador lo detecta.
- En el sitio solo va la llave pública (`sb_publishable_...`). Nunca la secreta.

## Agregar un módulo nuevo
1. Crear `assets/modulo.js` que termine con `iniciarPagina({ modulo:'modulo', dibujar:funcion })` (agregar `soloAdmin:true` si aplica).
2. Crear `modulo.html` copiando una página existente y cambiando su título y el script del módulo.
3. Sumar una línea a `PAGINAS` en `assets/sesion.js`.
4. Correr el flujo de arriba. Si el módulo toca una tabla nueva en Supabase, repetir antes la prueba de aislamiento entre empresas.

## Pruebas con errores sembrados
Los 10 tipos de error que el verificador detecta (archivo editado sin sellar, función inexistente, nombre repetido, versión escrita
a mano, error de sintaxis, página sin registrar, módulo mal enlazado, llave secreta, archivo huérfano, módulo sin iniciar) están
probados; si se cambia el verificador, repetir esa prueba.
