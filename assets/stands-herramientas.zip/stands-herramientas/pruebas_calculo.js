#!/usr/bin/env node
/* PRUEBAS DE CÁLCULO · verifica las fórmulas de dinero y de fechas de assets/calculo.js, caso por caso.
   Uso: node pruebas_calculo.js [carpeta-del-sitio] */
const fs = require('fs'), path = require('path'), vm = require('vm'), assert = require('assert');
const sitio = path.resolve(process.argv[2] || path.join(__dirname, '..', 'sitio'));
const codigo = fs.readFileSync(path.join(sitio, 'assets/calculo.js'), 'utf8');
const C = vm.runInNewContext(codigo + '\n;({ redondear, hoyMX, sumarDias, lunesDe, semanaDesdeHoy, fechaCorta, montoJornada, resumenSemana })', {});
let n = 0, malas = [];
const prueba = (nombre, fn) => { n++; try { fn(); console.log('  ✓ ' + nombre); } catch (e) { malas.push(nombre); console.log('  ✗ ' + nombre + '\n      ' + String(e.message).split('\n')[0]); } };
const plano = x => x === undefined ? undefined : JSON.parse(JSON.stringify(x));   // los objetos del entorno aislado se comparan por contenido
const eq = (a, b) => assert.deepStrictEqual(plano(a), plano(b));

console.log('Fechas');
prueba('a las 11:30 pm en CDMX sigue siendo hoy (el error de UTC lo marcaría mañana)', () => eq(C.hoyMX(new Date('2026-10-15T05:30:00Z')), '2026-10-14'));
prueba('pasada la medianoche en CDMX ya es el día siguiente', () => eq(C.hoyMX(new Date('2026-10-15T06:00:00Z')), '2026-10-15'));
prueba('el lunes de un miércoles es el lunes anterior', () => eq(C.lunesDe('2026-10-14'), '2026-10-12'));
prueba('el lunes de un domingo es 6 días antes, no el siguiente', () => eq(C.lunesDe('2026-10-18'), '2026-10-12'));
prueba('el lunes de un lunes es el mismo día', () => eq(C.lunesDe('2026-10-12'), '2026-10-12'));
prueba('cambio de mes: lunes de un jueves 1 de octubre', () => eq(C.lunesDe('2026-10-01'), '2026-09-28'));
prueba('cambio de año: sumar 3 días al 30 de diciembre', () => eq(C.sumarDias('2026-12-30', 3), '2027-01-02'));
prueba('semana actual (miércoles 14 de octubre)', () => eq(C.semanaDesdeHoy(0, new Date('2026-10-14T18:00:00Z')), { inicio:'2026-10-12', fin:'2026-10-18' }));
prueba('semana anterior', () => eq(C.semanaDesdeHoy(-1, new Date('2026-10-14T18:00:00Z')), { inicio:'2026-10-05', fin:'2026-10-11' }));
prueba('domingo 11:59 pm CDMX todavía es la semana que termina', () => eq(C.semanaDesdeHoy(0, new Date('2026-10-19T05:59:00Z')).inicio, '2026-10-12'));
prueba('lunes 12:00 am CDMX ya es la semana siguiente', () => eq(C.semanaDesdeHoy(0, new Date('2026-10-19T06:00:00Z')).inicio, '2026-10-19'));

console.log('Monto de una jornada');
prueba('jornada completa paga el día', () => eq(C.montoJornada(800, 8).sugerido, 800));
prueba('3 horas extra: 800 + 3 x $100 x 2 = 1,400 y no excede el máximo', () => { const r = C.montoJornada(800, 11); eq(r.sugerido, 1400); eq(r.excedeMaxExtra, false); eq(r.horasExtra, 3); });
prueba('4 horas extra: 1,600 y sí excede el máximo de 3', () => { const r = C.montoJornada(800, 12); eq(r.sugerido, 1600); eq(r.excedeMaxExtra, true); });
prueba('chalán con 2 horas extra: 500 + 2 x $62.50 x 2 = 750', () => eq(C.montoJornada(500, 10).sugerido, 750));
prueba('media jornada sin regla definida: sugiere por horas y da las dos cifras', () => { const r = C.montoJornada(800, 4); eq(r.parcial, true); eq(r.porHoras, 400); eq(r.diaCompleto, 800); eq(r.sugerido, 400); });
prueba('media jornada con regla "día completo" sugiere el día', () => eq(C.montoJornada(800, 4, { pago_dia_parcial:'dia_completo' }).sugerido, 800));
prueba('media jornada con regla "por horas" sugiere por horas', () => eq(C.montoJornada(800, 4, { pago_dia_parcial:'por_horas' }).sugerido, 400));
prueba('redondeo a centavos: $850 por 3 horas = 318.75', () => eq(C.montoJornada(850, 3, { pago_dia_parcial:'por_horas' }).sugerido, 318.75));
prueba('redondeo: $500 por 7 horas = 437.50', () => eq(C.montoJornada(500, 7, { pago_dia_parcial:'por_horas' }).sugerido, 437.5));
prueba('una jornada de otra duración usa SU jornada: 9 h de $900 con jornada de 9 h = 900', () => eq(C.montoJornada(900, 9, { jornada_horas:9 }).sugerido, 900));
prueba('sin tarifa (null) no inventa un monto', () => eq(C.montoJornada(null, 8).sugerido, null));
prueba('horas en 0 o negativas no dan monto', () => { eq(C.montoJornada(800, 0).sugerido, null); eq(C.montoJornada(800, -2).sugerido, null); });
prueba('una tarifa de $0 es válida y da $0', () => eq(C.montoJornada(0, 8).sugerido, 0));

console.log('Resumen semanal');
const sem = { inicio:'2026-10-12', fin:'2026-10-18' };
const gente = [{ id:'luis', activo:true }, { id:'rafa', activo:true, pago_semanal:3000 }, { id:'baja', activo:false, pago_semanal:2000 }];
const jor = [
  { personal_id:'luis', fecha:'2026-10-12', monto:800 }, { personal_id:'luis', fecha:'2026-10-13', monto:800 }, { personal_id:'luis', fecha:'2026-10-14', monto:400 },
  { personal_id:'luis', fecha:'2026-10-14', monto:999, anulada:true },          // anulada: no cuenta
  { personal_id:'luis', fecha:'2026-10-19', monto:800 },                        // otra semana
  { personal_id:'luis', fecha:'2026-10-11', monto:800 } ];                      // semana anterior
const pag = [ { personal_id:'luis', semana_inicio:'2026-10-12', monto:1000 }, { personal_id:'luis', semana_inicio:'2026-10-12', monto:300, anulado:true }, { personal_id:'luis', semana_inicio:'2026-10-05', monto:500 } ];
const res = C.resumenSemana(gente, jor, pag, sem), por = id => res.find(f => f.personal_id === id);
prueba('suma solo las jornadas de la semana y descarta anuladas', () => { eq(por('luis').sumaJornadas, 2000); eq(por('luis').jornadas.length, 3); });
prueba('descuenta solo pagos de esa semana y no anulados', () => { eq(por('luis').pagado, 1000); eq(por('luis').restante, 1000); });
prueba('pago a medias queda "parcial"', () => eq(por('luis').estado, 'parcial'));
prueba('sueldo fijo sin pagos queda "pendiente" por el total', () => { eq(por('rafa').total, 3000); eq(por('rafa').estado, 'pendiente'); });
prueba('una persona dada de baja no suma su sueldo fijo', () => eq(por('baja'), undefined));
prueba('pagar de menos por 50 centavos se da por cubierto', () => { const r = C.resumenSemana([{ id:'x', activo:true, pago_semanal:1000 }], [], [{ personal_id:'x', semana_inicio:'2026-10-12', monto:999.6 }], sem); eq(r[0].estado, 'cubierto'); });
prueba('pagar de más se marca "excedido"', () => { const r = C.resumenSemana([{ id:'x', activo:true, pago_semanal:1000 }], [], [{ personal_id:'x', semana_inicio:'2026-10-12', monto:1500 }], sem); eq(r[0].estado, 'excedido'); eq(r[0].restante, -500); });
prueba('dos pagos parciales suman y cubren', () => { const r = C.resumenSemana([{ id:'x', activo:true, pago_semanal:1000 }], [], [{ personal_id:'x', semana_inicio:'2026-10-12', monto:600 }, { personal_id:'x', semana_inicio:'2026-10-12', monto:400 }], sem); eq(r[0].estado, 'cubierto'); });
prueba('el sueldo fijo no cuenta en semanas anteriores al ingreso', () => { eq(C.resumenSemana([{ id:'n', activo:true, pago_semanal:2000, fecha_ingreso:'2026-10-19' }], [], [], sem), []); eq(C.resumenSemana([{ id:'n', activo:true, pago_semanal:2000, fecha_ingreso:'2026-10-18' }], [], [], sem)[0].total, 2000); });
prueba('sin sueldo ni jornadas ni pagos no aparece nadie', () => eq(C.resumenSemana([{ id:'x', activo:true }], [], [], sem), []));
prueba('sumas con decimales no acumulan error (0.1 + 0.2)', () => { const r = C.resumenSemana([{ id:'x', activo:true }], [{ personal_id:'x', fecha:'2026-10-12', monto:0.1 }, { personal_id:'x', fecha:'2026-10-13', monto:0.2 }], [], sem); eq(r[0].total, 0.3); });

console.log(`\n${n - malas.length} de ${n} pruebas de cálculo correctas.`);
if (malas.length) { console.log('FALLARON:\n  - ' + malas.join('\n  - ')); process.exit(1); }
