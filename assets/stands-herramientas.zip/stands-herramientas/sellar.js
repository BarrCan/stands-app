#!/usr/bin/env node
/* SELLADOR · pone a cada referencia de las páginas una huella del contenido del archivo
   (assets/x.js?v=HUELLA). Si un archivo cambia, su huella cambia y el navegador lo descarga de nuevo;
   si no cambia, sigue usando el guardado. Así nunca se mezclan versiones.
   Uso:  node sellar.js [carpeta-del-sitio] [--registrar]
   --registrar guarda el estado actual como "última entrega" (manifiesto.json). */
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const args = process.argv.slice(2);
const sitio = path.resolve(args.find(a => !a.startsWith('--')) || path.join(__dirname, '..', 'sitio'));
const registrar = args.includes('--registrar');
const manifiestoRuta = path.join(__dirname, 'manifiesto.json');

const huella = f => crypto.createHash('sha1').update(fs.readFileSync(f)).digest('hex').slice(0, 8);
const listar = (dir, base = dir) => fs.readdirSync(dir, { withFileTypes: true }).flatMap(d =>
  d.isDirectory() ? listar(path.join(dir, d.name), base) : [path.relative(base, path.join(dir, d.name)).split(path.sep).join('/')]);

// 1. sellar las referencias de cada página
const paginas = listar(sitio).filter(f => f.endsWith('.html'));
let sellos = 0;
for (const pg of paginas) {
  const ruta = path.join(sitio, pg);
  const antes = fs.readFileSync(ruta, 'utf8');
  const despues = antes.replace(/(src|href)="(assets\/[^"?]+)(\?v=[0-9a-f]*)?"/g, (m, attr, rel) => {
    const f = path.join(sitio, rel);
    if (!fs.existsSync(f)) { console.error(`✗ ${pg}: referencia a un archivo que no existe: ${rel}`); process.exitCode = 1; return m; }
    sellos++; return `${attr}="${rel}?v=${huella(f)}"`;
  });
  if (despues !== antes) fs.writeFileSync(ruta, despues);
}
console.log(`Sellado: ${sellos} referencias en ${paginas.length} páginas.`);

// 2. qué cambió desde la última entrega
const actual = {}; for (const f of listar(sitio)) actual[f] = huella(path.join(sitio, f));
const previo = fs.existsSync(manifiestoRuta) ? JSON.parse(fs.readFileSync(manifiestoRuta, 'utf8')) : null;
if (!previo) { console.log('No hay entrega anterior registrada: se deben subir todos los archivos.'); }
else {
  const nuevos = Object.keys(actual).filter(f => !(f in previo)), cambiados = Object.keys(actual).filter(f => f in previo && previo[f] !== actual[f]);
  const borrados = Object.keys(previo).filter(f => !(f in actual));
  console.log('\nArchivos a subir a GitHub (nuevos o modificados):');
  [...nuevos, ...cambiados].sort().forEach(f => console.log('  •', f, nuevos.includes(f) ? '(nuevo)' : ''));
  if (!nuevos.length && !cambiados.length) console.log('  (ninguno: no hay cambios)');
  if (borrados.length) { console.log('\nArchivos que ya no existen y se deben borrar del repositorio:'); borrados.forEach(f => console.log('  •', f)); }
}
if (registrar) { fs.writeFileSync(manifiestoRuta, JSON.stringify(actual, null, 2)); console.log('\nEntrega registrada como base de comparación.'); }
