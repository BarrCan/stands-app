/* SOLO PARA PRUEBAS: imita a Supabase en el navegador (sin red). No se sube al sitio. */
(function(){
  const cfg = JSON.parse(localStorage.getItem('stub_cfg') || '{}');
  const pz = [['p1','PISO-1X1','Piso','pieza',858,180,0],['p2','MURO-1X2','Muro','pieza',995,60,60],['p3','PINTADO-M2','Pintado','m2',350,0,20],['p4','CONT-OVALO','Contenedor ovalado','pieza',1850,480,0]];
  const costo = (mat,mc,mh) => ({ costo_hora_calificado:100, costo_hora_chalan:62.5, costo_mano_obra:+(mc/60*100+mh/60*62.5).toFixed(2), costo_total:+(mat+mc/60*100+mh/60*62.5).toFixed(2) });
  const hoyMX = new Date().toLocaleDateString('en-CA', { timeZone:'America/Mexico_City' });
  const sumar = (iso, d) => { const [y,m,dd] = iso.split('-').map(Number); return new Date(Date.UTC(y, m-1, dd + d)).toISOString().slice(0,10); };
  const lunes = (() => { const [y,m,d] = hoyMX.split('-').map(Number); const dow = new Date(Date.UTC(y,m-1,d)).getUTCDay(); return sumar(hoyMX, -(dow === 0 ? 6 : dow - 1)); })();
  const semilla = () => ({
    perfiles: cfg.sinPerfil ? [] : [{ id:'u1', empresa_id:'e1', rol:cfg.rol||'admin', es_superadmin:cfg.sup!==false && (cfg.rol||'admin')==='admin' }],
    empresas: [{ id:'e1', nombre:'Estructuras Demo', tema:{ preset:'taller' }, razon_social:null, rfc:null, direccion:null }],
    canales_origen: ['Recomendación','Expo o evento','Redes sociales','Alianza o agencia'].map((n,i) => ({ id:'c'+(i+1), nombre:n, activo:true, orden:i+1 })),
    clientes: [{ id:'k1', nombre:'Omar Barrera', canal_id:'c4', telefono:'55 1234 5678', empresa_cliente:'Agencia de eventos', cargo:'Director', creado_en:'2026-08-20T15:00:00Z' }],
    v_catalogo_vigente: pz.map(p => ({ concepto_id:p[0], codigo:p[1], nombre:p[2], unidad:p[3], activo:true, costo_material:p[4], minutos_calificado:p[5], minutos_chalan:p[6], vigente_desde:'2026-10-14', ...costo(p[4],p[5],p[6]) })),
    tarifas_mano_obra: [{ id:'t1', nombre:'Oficial', rol:'calificado', pago_dia:1200, es_referencia:false, activo:true }, { id:'t2', nombre:'Semi oficial', rol:'calificado', pago_dia:800, es_referencia:true, activo:true }, { id:'t3', nombre:'Chalán', rol:'chalan', pago_dia:500, es_referencia:true, activo:true }],
    parametros_costeo: [{ empresa_id:'e1', jornada_horas:8, factor_hora_extra:2, max_horas_extra_dia:3, pago_dia_parcial:'sin_definir' }],
    auditoria_costos: [{ id:1, tabla:'catalogo_precios', accion:'INSERT', usuario_id:null, antes:null, despues:{ concepto_id:'p2', costo_material:995, minutos_calificado:60, minutos_chalan:60 }, motivo:'Carga inicial', creado_en:'2026-10-14T15:00:00Z' }],
    catalogo_precios: [], catalogo_conceptos: [],
    personal: [
      { id:'pe1', nombre:'Luis Prueba', tipo:'eventual', tarifa_id:'t2', puesto:'Taller', pago_semanal:null, telefono:'5511111111', activo:true, fecha_ingreso:null },
      { id:'pe2', nombre:'Mario Chalan', tipo:'eventual', tarifa_id:'t3', puesto:null, pago_semanal:null, telefono:null, activo:true, fecha_ingreso:null },
      { id:'pe3', nombre:'Rafa Planta', tipo:'planta', tarifa_id:'t1', puesto:'Instalacion', pago_semanal:3000, telefono:null, activo:true, fecha_ingreso:'2026-01-05' } ],
    jornadas_personal: [
      { id:'jo1', personal_id:'pe1', fecha:lunes, horas:8, nivel_nombre:'Semi oficial', pago_dia:800, monto:800, referencia:'STAN-003A', nota:null, anulada:false, creado_en:'2026-10-12T15:00:00Z' },
      { id:'jo2', personal_id:'pe1', fecha:lunes, horas:8, nivel_nombre:'Semi oficial', pago_dia:800, monto:800, referencia:'STAN-003A', nota:null, anulada:false, creado_en:'2026-10-12T16:00:00Z' } ],
    pagos_personal: []
  });
  const db = JSON.parse(localStorage.getItem('stub_db') || 'null') || semilla();
  const guardar = () => localStorage.setItem('stub_db', JSON.stringify(db));
  let seq = Number(localStorage.getItem('stub_seq') || 100);
  const MOT = { message:'Escribe el motivo del cambio (mínimo 5 caracteres)' };
  window.supabase = { createClient(){
    const sesion = () => localStorage.getItem('stub_sesion') ? { user:{ id:'u1', email:'demo@ejemplo.com' } } : null;
    function from(t){
      let op='select', payload=null, f=[], one=false, maybe=false;
      const q = { select(){return q}, order(){return q}, limit(){return q}, eq(c,v){f.push([c,v]);return q}, gte(c,v){f.push([c,v,'gte']);return q}, lte(c,v){f.push([c,v,'lte']);return q}, insert(p){op='insert';payload=p;return q}, update(p){op='update';payload=p;return q}, delete(){op='delete';return q}, single(){one=true;return q}, maybeSingle(){maybe=true;return q},
        then(res){ try {
          const rows = db[t]; if (!rows) return res({ data:null, error:{ message:'relation '+t+' does not exist' } });
          const m = r => f.every(([c,v,o]) => o === 'gte' ? r[c] >= v : o === 'lte' ? r[c] <= v : r[c] === v); let out;
          if (op === 'select') out = rows.filter(m);
          else if (op === 'insert') {
            if (t === 'canales_origen' && rows.some(r => r.nombre.toLowerCase() === payload.nombre.toLowerCase())) return res({ data:null, error:{ message:'duplicate key value 23505' } });
            if (t === 'catalogo_precios') {
              if (!payload.nota || payload.nota.trim().length < 5) return res({ data:null, error:MOT });
              const v = db.v_catalogo_vigente.find(x => x.concepto_id === payload.concepto_id);
              if (v) { Object.assign(v, { costo_material:payload.costo_material, minutos_calificado:payload.minutos_calificado, minutos_chalan:payload.minutos_chalan }); Object.assign(v, costo(v.costo_material, v.minutos_calificado||0, v.minutos_chalan||0)); }
              db.auditoria_costos.unshift({ id:++seq, tabla:t, accion:'INSERT', usuario_id:'u1', antes:null, despues:payload, motivo:payload.nota, creado_en:new Date().toISOString() });
            }
            if (t === 'catalogo_conceptos') {
              if (!payload.motivo_cambio || payload.motivo_cambio.length < 5) return res({ data:null, error:MOT });
              const id = 'n' + (++seq);
              db.v_catalogo_vigente.push({ concepto_id:id, codigo:payload.codigo, nombre:payload.nombre, unidad:payload.unidad, activo:true, costo_material:null, minutos_calificado:null, minutos_chalan:null, costo_total:null, costo_mano_obra:null, costo_hora_calificado:100, costo_hora_chalan:62.5 });
              guardar(); localStorage.setItem('stub_seq', seq); return res({ data:{ id }, error:null });
            }
            const r = { id:'n'+(++seq), activo:true, creado_en:new Date().toISOString(), ...payload }; if (t === 'clientes') rows.unshift(r); else rows.push(r); out = [r];
          }
          else if (op === 'update') {
            if (t === 'jornadas_personal' || t === 'pagos_personal') { if (!payload.motivo_cambio || payload.motivo_cambio.length < 5) return res({ data:null, error:MOT }); }
            if (t === 'personal') { const antes = rows.find(m); if (antes && ((('tarifa_id' in payload) && (payload.tarifa_id || null) !== (antes.tarifa_id || null)) || (('pago_semanal' in payload) && (payload.pago_semanal ?? null) !== (antes.pago_semanal ?? null)))) { if (!payload.motivo_cambio || payload.motivo_cambio.length < 5) return res({ data:null, error:MOT }); } }
            if (t === 'tarifas_mano_obra' || t === 'parametros_costeo') { if (!payload.motivo_cambio || payload.motivo_cambio.length < 5) return res({ data:null, error:MOT }); }
            out = rows.filter(m); out.forEach(r => Object.assign(r, payload));
          }
          else { out = rows.filter(m); db[t] = rows.filter(r => !m(r)); out = []; }
          guardar(); localStorage.setItem('stub_seq', seq);
          res({ data:(one||maybe) ? (out[0]||null) : out, error:null });
        } catch(e){ res({ data:null, error:{ message:String(e) } }); } } };
      return q;
    }
    const storage = { from(bucket){ return {
      upload: async (ruta) => { if ((cfg.rol||'admin') !== 'admin') return { data:null, error:{ message:'new row violates row-level security policy' } }; (db.archivos = db.archivos || []).push(ruta); guardar(); return { data:{ path:ruta }, error:null }; },
      remove: async (rutas) => { db.archivos = (db.archivos || []).filter(r => !rutas.includes(r)); guardar(); return { data:[], error:null }; },
      getPublicUrl: (ruta) => ({ data:{ publicUrl:'https://stub.local/storage/' + bucket + '/' + ruta } }) }; } };
    return { from, storage, rpc: async (n) => { if (n === 'crear_empresa') { db.perfiles.push({ id:'u1', empresa_id:'e1', rol:'admin', es_superadmin:true }); guardar(); } return { error:null }; },
      auth:{ getSession: async () => ({ data:{ session:sesion() } }), onAuthStateChange(){},
        signInWithPassword: async () => { localStorage.setItem('stub_sesion','1'); return { data:sesion(), error:null }; },
        signUp: async () => ({ data:{ session:null }, error:null }),
        signOut: async () => { localStorage.removeItem('stub_sesion'); return {}; } } };
  } };
})();
