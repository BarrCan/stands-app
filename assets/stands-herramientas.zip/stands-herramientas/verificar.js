#!/usr/bin/env node
/* VERIFICADOR · revisa todo el sitio antes de entregarlo. Termina con error si algo falla.
   Uso:  node verificar.js [carpeta-del-sitio]
   Revisa: archivos referenciados y huellas, versión escrita a mano, llave pública, sintaxis, nombres
   repetidos entre archivos de una misma página, nombres usados pero no definidos, y que cada página
   esté bien registrada en la navegación. */
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const acorn = require('acorn'), { ESLint } = require('eslint');
const sitio = path.resolve(process.argv[2] || path.join(__dirname, '..', 'sitio'));
const huella = f => crypto.createHash('sha1').update(fs.readFileSync(f)).digest('hex').slice(0, 8);
const listar = (dir, base = dir) => fs.readdirSync(dir, { withFileTypes: true }).flatMap(d =>
  d.isDirectory() ? listar(path.join(dir, d.name), base) : [path.relative(base, path.join(dir, d.name)).split(path.sep).join('/')]);
const leer = f => fs.readFileSync(path.join(sitio, f), 'utf8');

const errores = [], avisos = []; let comprobaciones = 0;
const ok = (c, msg) => { comprobaciones++; if (!c) errores.push(msg); return c; };
const archivos = listar(sitio), paginas = archivos.filter(f => f.endsWith('.html')), assets = archivos.filter(f => f.startsWith('assets/'));

// 1. referencias y huellas
const refPorPagina = {}, referenciados = new Set();
for (const pg of paginas) {
  const html = leer(pg), refs = [...html.matchAll(/(?:src|href)="(assets\/[^"?]+)(\?v=([0-9a-f]*))?"/g)];
  refPorPagina[pg] = refs.filter(m => m[1].endsWith('.js')).map(m => m[1]);
  for (const m of refs) {
    referenciados.add(m[1]);
    if (!ok(fs.existsSync(path.join(sitio, m[1])), `${pg}: referencia a un archivo que no existe (${m[1]})`)) continue;
    ok(m[3] === huella(path.join(sitio, m[1])), `${pg}: la huella de ${m[1]} no coincide con su contenido (se editó sin volver a sellar)`);
  }
  ok(/<div id="app">/.test(html) && /<div id="toast"/.test(html) && /<div id="layer">/.test(html), `${pg}: faltan los contenedores base (#app, #toast, #layer)`);
}
for (const a of assets) ok(referenciados.has(a), `${a}: ningún página lo usa (archivo huérfano)`);

// 2. versión escrita a mano y llave
for (const f of archivos) {
  if (f === 'assets/version.js') continue;
  const t = leer(f);
  ok(!/\bv\d+\.\d+\.\d+\b/.test(t), `${f}: tiene una versión escrita a mano; la versión solo vive en assets/version.js`);
  ok(!/APP_VERSION\s*=/.test(t), `${f}: define APP_VERSION; solo puede definirse en assets/version.js`);
  ok(!/sb_secret_|service_role/i.test(t), `${f}: contiene una llave SECRETA; nunca debe ir en el sitio`);
}
ok(/SUPABASE_KEY\s*=\s*'sb_publishable_[A-Za-z0-9_\-]+'/.test(leer('assets/config.js')), 'assets/config.js: SUPABASE_KEY no es una llave pública (sb_publishable_...)');
ok(/APP_VERSION\s*=\s*'v\d+\.\d+\.\d+'/.test(leer('assets/version.js')), 'assets/version.js: APP_VERSION no tiene el formato vX.Y.Z');

// 3. sintaxis y nombres globales
const nombres = patron => patron.type === 'Identifier' ? [patron.name] : patron.type === 'ObjectPattern' ? patron.properties.flatMap(p => nombres(p.value || p.argument)) :
  patron.type === 'ArrayPattern' ? patron.elements.filter(Boolean).flatMap(nombres) : patron.type === 'AssignmentPattern' ? nombres(patron.left) : patron.type === 'RestElement' ? nombres(patron.argument) : [];
const declaraciones = {};
for (const js of assets.filter(a => a.endsWith('.js'))) {
  try {
    const ast = acorn.parse(leer(js), { ecmaVersion: 2022, sourceType: 'script' }); const n = [];
    for (const nodo of ast.body) {
      if (nodo.type === 'FunctionDeclaration' || nodo.type === 'ClassDeclaration') n.push(nodo.id.name);
      if (nodo.type === 'VariableDeclaration') nodo.declarations.forEach(d => n.push(...nombres(d.id)));
    }
    declaraciones[js] = n;
  } catch (e) { ok(false, `${js}: error de sintaxis (línea ${e.loc && e.loc.line}): ${e.message}`); declaraciones[js] = []; }
}
(async () => {
  for (const pg of paginas) {
    const scripts = refPorPagina[pg], dueno = {};
    for (const js of scripts) for (const n of declaraciones[js] || []) {
      if (dueno[n] && dueno[n] !== js) ok(false, `${pg}: el nombre "${n}" está definido en ${dueno[n]} y también en ${js} (uno pisaría al otro)`);
      dueno[n] = js;
    }
    const globales = {}; Object.keys(dueno).forEach(n => globales[n] = 'writable');
    const eslint = new ESLint({ useEslintrc: false, overrideConfig: {
      env: { browser: true, es2022: true }, parserOptions: { ecmaVersion: 2022, sourceType: 'script' }, globals: globales,
      rules: { 'no-undef': 'error', 'no-const-assign': 'error', 'no-dupe-keys': 'error', 'no-func-assign': 'error', 'no-dupe-else-if': 'error', 'no-unreachable': 'error' } } });
    for (const js of scripts) {
      const res = await eslint.lintText(leer(js), { filePath: path.join(sitio, js) });
      for (const m of res[0].messages) ok(false, `${js} (en ${pg}), línea ${m.line}: ${m.message}`);
      comprobaciones++;
    }
  }
  // 4. navegación y módulos
  const ses = leer('assets/sesion.js'), registradas = [...ses.matchAll(/k:'(\w+)',[^}]*url:'([\w\-]+\.html)'/g)].map(m => ({ k: m[1], url: m[2] }));
  ok(registradas.length > 0, 'assets/sesion.js: no se encontró la lista PAGINAS');
  for (const r of registradas) {
    if (!ok(paginas.includes(r.url), `PAGINAS apunta a ${r.url}, que no existe`)) continue;
    const modulo = refPorPagina[r.url].map(j => j).find(j => new RegExp(`iniciarPagina\\(\\{[^}]*modulo:'${r.k}'`).test(leer(j)));
    ok(!!modulo, `${r.url}: ningún archivo de la página llama a iniciarPagina({ modulo:'${r.k}' ... })`);
  }
  for (const pg of paginas.filter(p => p !== 'index.html')) ok(registradas.some(r => r.url === pg), `${pg}: no está registrada en PAGINAS (no aparecería en la navegación)`);

  console.log(`Sitio: ${paginas.length} páginas, ${assets.length} archivos en assets/.`);
  if (errores.length) { console.log(`\n✗ ${errores.length} problema(s) en ${comprobaciones} comprobaciones:\n`); errores.forEach(e => console.log('  ✗', e)); process.exit(1); }
  console.log(`✓ ${comprobaciones} comprobaciones sin problemas.`);
})();
